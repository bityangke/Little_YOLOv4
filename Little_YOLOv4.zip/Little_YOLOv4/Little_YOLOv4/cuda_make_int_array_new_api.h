
#ifndef CUDA_MAKE_INT_ARRAY_NEW_API
#define CUDA_MAKE_INT_ARRAY_NEW_API


int* cuda_make_int_array_new_api(int* x, size_t n);


#endif