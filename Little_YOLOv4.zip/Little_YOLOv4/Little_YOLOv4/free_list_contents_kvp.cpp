
#include "list.h"
#include "kvp.h"
#include <stdlib.h>


void free_list_contents_kvp(list* l)
{
    node* n = l->front;
    while (n) {
        kvp* p = (kvp*)n->val;
        free(p->key);
        free(n->val);
        n = n->next;
    }
}