
#ifndef NETWORK_PREDICT_GPU
#define NETWORK_PREDICT_GPU


#include "network.h"


float* network_predict_gpu(network net, float* input);


#endif