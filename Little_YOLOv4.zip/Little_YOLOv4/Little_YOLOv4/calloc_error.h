
#ifndef CALLOC_ERROR
#define CALLOC_ERROR


void calloc_error();


#endif