
#ifndef FIND_FLOAT_ARG
#define FIND_FLOAT_ARG


float find_float_arg(int argc, char** argv, char* arg, float def);


#endif