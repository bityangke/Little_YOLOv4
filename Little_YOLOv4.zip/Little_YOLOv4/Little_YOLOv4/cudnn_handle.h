
#ifndef CUDNN_HANDLE
#define CUDNN_HANDLE


#include <cudnn.h>


cudnnHandle_t cudnn_handle();


#endif