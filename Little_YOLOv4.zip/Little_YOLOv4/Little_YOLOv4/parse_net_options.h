
#ifndef PARSE_NET_OPTIONS
#define PARSE_NET_OPTIONS


#include "list.h"
#include "network.h"


void parse_net_options(list* options, network* net);


#endif