
#include <opencv2\opencv.hpp>


void destroy_all_windows_cv()
{
    cv::destroyAllWindows();
}