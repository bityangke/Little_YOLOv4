
#include <opencv2\opencv.hpp>
#include "image.h"


cv::Mat image_to_mat(image img);