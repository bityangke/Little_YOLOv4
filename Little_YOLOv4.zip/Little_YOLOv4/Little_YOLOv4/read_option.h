
#ifndef READ_OPTION
#define READ_OPTION


int read_option(char* s, list* options);


#endif