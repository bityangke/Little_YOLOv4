
#ifndef FREE_CONVOLUTIONAL_BATCHNORM
#define FREE_CONVOLUTIONAL_BATCHNORM


#include "layer.h"


void free_convolutional_batchnorm(layer* l);


#endif