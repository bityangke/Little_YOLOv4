
#ifndef DRAW_BOX
#define DRAW_BOX


#include "image.h"


void draw_box(image a, int x1, int y1, int x2, int y2, float r, float g, float b);


#endif