
#ifndef BOX
#define BOX


typedef struct box {
    float x, y, w, h;
} box;


#endif