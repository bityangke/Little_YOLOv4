
#ifndef FILL_CPU
#define FILL_CPU


void fill_cpu(int N, float ALPHA, float* X, int INCX);


#endif