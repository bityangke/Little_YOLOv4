
#ifndef MAKE_LIST
#define MAKE_LIST


list* make_list();


#endif