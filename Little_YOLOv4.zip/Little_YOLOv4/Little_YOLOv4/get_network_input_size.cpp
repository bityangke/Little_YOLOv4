
#include "network.h"


int get_network_input_size(network net)
{
    return net.layers[0].inputs;
}