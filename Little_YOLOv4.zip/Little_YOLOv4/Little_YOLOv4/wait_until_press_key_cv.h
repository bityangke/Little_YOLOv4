
#ifndef WAIT_UNTIL_PRESS_KEY_CV
#define WAIT_UNTIL_PRESS_KEY_CV


int wait_until_press_key_cv();


#endif