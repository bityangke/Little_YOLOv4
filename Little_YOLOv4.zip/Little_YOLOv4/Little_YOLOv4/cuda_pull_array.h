
#ifndef CUDA_PULL_ARRAY
#define CUDA_PULL_ARRAY


void cuda_pull_array(float* x_gpu, float* x, size_t n);


#endif