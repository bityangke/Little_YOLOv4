
#ifndef FREE_NETWORK
#define FREE_NETWORK


#include "network.h"


void free_network(network net);


#endif