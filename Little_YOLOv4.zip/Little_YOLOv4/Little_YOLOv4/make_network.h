
#ifndef MAKE_NETWORK
#define MAKE_NETWORK


#include "network.h"


network make_network(int n);


#endif