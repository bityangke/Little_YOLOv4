
#ifndef BOX_INTERSECTION
#define BOX_INTERSECTION


#include "box.h"


float box_intersection(box a, box b);


#endif