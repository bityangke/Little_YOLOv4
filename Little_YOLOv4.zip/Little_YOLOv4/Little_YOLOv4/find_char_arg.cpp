
#include <string.h>


char* find_char_arg(int argc, char** argv, char* arg, char* def)
{
    for (int i = 0; i < argc - 1; ++i) {
        if (strcmp(argv[i], arg) == 0) {
            return argv[i + 1];
        }
    }
    return def;
}