
#include "layer.h"
#include "network_state.h"


void forward_route_layer_gpu(const layer l, network_state state);