
#ifndef FREE_LAYER_CUSTOM
#define FREE_LAYER_CUSTOM


#include "layer.h"


void free_layer_custom(layer l, int keep_cudnn_desc);


#endif