
#ifndef GET_NETWORK_OUTPUT_LAYER_GPU
#define GET_NETWORK_OUTPUT_LAYER_GPU


#include "network.h"


float* get_network_output_layer_gpu(network net, int i);


#endif