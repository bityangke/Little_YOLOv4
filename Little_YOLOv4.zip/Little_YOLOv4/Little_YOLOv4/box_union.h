
#ifndef BOX_UNION
#define BOX_UNION


#include "box.h"


float box_union(box a, box b);


#endif