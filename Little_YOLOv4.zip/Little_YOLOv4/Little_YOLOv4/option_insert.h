
#ifndef OPTION_INSERT
#define OPTION_INSERT


void option_insert(list* l, char* key, char* val);


#endif