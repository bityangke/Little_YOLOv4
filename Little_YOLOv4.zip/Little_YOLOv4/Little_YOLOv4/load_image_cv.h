
#ifndef LOAD_IMAGE_CV
#define LOAD_IMAGE_CV


#include "image.h"


image load_image_cv(char* filename, int channels);


#endif