
#include <string.h>


int find_arg(int argc, char* argv[], char* arg)
{
    for (int i = 0; i < argc; ++i) {
        if (strcmp(argv[i], arg) == 0) {
            return 1;
        }
    }
    return 0;
}