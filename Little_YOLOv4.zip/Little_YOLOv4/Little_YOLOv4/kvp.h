
#ifndef KVP
#define KVP


typedef struct {
    char* key;
    char* val;
} kvp;


#endif