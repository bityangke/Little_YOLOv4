
#ifndef MALLOC_ERROR
#define MALLOC_ERROR


void malloc_error();


#endif