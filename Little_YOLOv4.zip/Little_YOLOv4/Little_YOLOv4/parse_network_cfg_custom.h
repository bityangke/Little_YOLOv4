
#ifndef PARSE_NETWORK_CFG_CUSTOM
#define PARSE_NETWORK_CFG_CUSTOM


#include "network.h"


network parse_network_cfg_custom(char* filename, int batch, int time_steps);


#endif