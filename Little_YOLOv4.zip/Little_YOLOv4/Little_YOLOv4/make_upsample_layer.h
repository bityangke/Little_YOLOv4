
#ifndef MAKE_UPSAMPLE_LAYER
#define MAKE_UPSAMPLE_LAYER


#include "layer.h"


layer make_upsample_layer(int batch, int w, int h, int c, int stride);


#endif