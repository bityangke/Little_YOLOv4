
#ifndef ADD_PIXEL
#define ADD_PIXEL


#include "image.h"


void add_pixel(image m, int x, int y, int c, float val);


#endif