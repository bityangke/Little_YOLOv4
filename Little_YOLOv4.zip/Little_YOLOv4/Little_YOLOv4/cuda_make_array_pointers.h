
#ifndef CUDA_MAKE_ARRAY_POINTERS
#define CUDA_MAKE_ARRAY_POINTERS


void** cuda_make_array_pointers(void** x, size_t n);


#endif