
#include "image.h"
#include "load_image.h"


image load_image_color(char* filename, int w, int h)
{
    return load_image(filename, w, h, 3);
}