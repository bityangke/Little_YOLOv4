
#include <opencv2\opencv.hpp>


void* load_image_mat_cv(const char* filename, int flag)
{
    cv::Mat mat = cv::imread(filename, flag);
    cv::cvtColor(mat, mat, cv::COLOR_RGB2BGR);
    cv::Mat* mat_ptr = new cv::Mat(mat);
    return mat_ptr;
}