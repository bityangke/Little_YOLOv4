
#ifndef FREE_LIST
#define FREE_LIST


#include "list.h"


void free_list(list* l);


#endif