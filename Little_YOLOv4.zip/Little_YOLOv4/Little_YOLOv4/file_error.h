
#ifndef FILE_ERROR
#define FILE_ERROR


void file_error(char* s);


#endif