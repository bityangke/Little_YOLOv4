
#include "list.h"
#include "read_data_cfg.h"
#include "option_find_str.h"
#include "get_labels_custom.h"
#include "image.h"
#include "load_alphabet.h"
#include "network.h"
#include "parse_network_cfg_custom.h"
#include "load_weights.h"
#include "fuse_conv_batchnorm.h"
#include "load_image.h"
#include "resize_image.h"
#include "network_predict.h"
#include "detection.h"
#include "get_network_boxes.h"
#include "diounms_sort.h"
#include "draw_detections_v3.h"
#include "show_image.h"
#include "wait_until_press_key_cv.h"
#include "destroy_all_windows_cv.h"
#include "free_detections.h"
#include "free_image.h"
#include "free_ptrs.h"
#include "free_list_contents_kvp.h"
#include "free_list.h"
#include <stdlib.h>
#include "free_network.h"

// For testing options.
/*#include "kvp.h"
#include <stdio.h>*/

// For testing names or alphabet.
//#include <stdio.h>

void test_detector(
    char* datacfg,
    char* cfgfile,
    char* weightfile,
    char* filename,
    float thresh,
    float hier_thresh,
    int dont_show,
    int ext_output,
    int save_labels,
    char* outfile,
    int letter_box,
    int benchmark_layers)
{
    list* options = read_data_cfg(datacfg);
    /*printf("Options:\n");
    node* presentNode = options->front;
    while (presentNode) {
        kvp* keyValuePair = (kvp*)presentNode->val;
        char* key = keyValuePair->key;
        char* val = keyValuePair->val;
        printf("%s: %s\n", key, val);
        presentNode = presentNode->next;
    }*/

    char* name_list = option_find_str(options, "names", "data/names.list");
    int names_size = 0;
    char** names = get_labels_custom(name_list, &names_size);
    /*for (int i = 0; i < names_size; ++i) {
        printf("'%s'\n", names[i]);
    }*/

    image** alphabet = load_alphabet();
    /*for (int i = 0; i < 8; ++i) {
        image* oneAlphabet = alphabet[i];
        for (int j = 32; j < 127; ++j) {
            image alphabeticCharacter = oneAlphabet[j];
            printf("c: %d; h: %d; w: %d; data: {",
                alphabeticCharacter.c, alphabeticCharacter.h, alphabeticCharacter.w);
            for (int k = 0; k < 20; ++k) {
                printf("%f, ", alphabeticCharacter.data[k]);
            }
            printf("... }\n");
        }
    }*/

    network net = parse_network_cfg_custom(cfgfile, 1, 1);

    load_weights(&net, weightfile);

    fuse_conv_batchnorm(net);

    float nms = 0.45;

    image im = load_image(filename, 0, 0, net.c);
    image sized = resize_image(im, net.w, net.h);
    float* X = sized.data;

    network_predict(net, X);

    int nboxes = 0;
    detection* dets = get_network_boxes(&net, im.w, im.h, thresh, hier_thresh, 0, 1, &nboxes, letter_box);

    layer l = net.layers[net.n - 1];
    diounms_sort(dets, nboxes, l.classes, nms, l.nms_kind, l.beta_nms);

    draw_detections_v3(im, dets, nboxes, thresh, names, alphabet, l.classes, ext_output);

    show_image(im, "predictions");
    wait_until_press_key_cv();

    destroy_all_windows_cv();
    free_detections(dets, nboxes);
    free_image(im);
    free_image(sized);
    free_ptrs((void**)names, net.layers[net.n - 1].classes);
    free_list_contents_kvp(options);
    free_list(options);
    int nsize = 8;
    int i;
    for (int j = 0; j < nsize; ++j) {
        for (i = 32; i < 127; ++i) {
            free_image(alphabet[j][i]);
        }
        free(alphabet[j]);
    }
    free(alphabet);
    free_network(net);
}