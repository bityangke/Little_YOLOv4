
#ifndef DESTROY_ALL_WINDOWS_CV
#define DESTROY_ALL_WINDOWS_CV


void destroy_all_windows_cv();


#endif