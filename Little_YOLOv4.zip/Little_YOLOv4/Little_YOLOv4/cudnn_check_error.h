
#ifndef CUDNN_CHECK_ERROR
#define CUDNN_CHECK_ERROR


#include <cudnn.h>


void cudnn_check_error(cudnnStatus_t status);


#endif