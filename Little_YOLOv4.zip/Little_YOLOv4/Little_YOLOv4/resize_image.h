
#ifndef RESIZE_IMAGE
#define RESIZE_IMAGE


#include "image.h"


image resize_image(image im, int w, int h);


#endif