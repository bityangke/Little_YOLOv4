
#ifndef SET_PIXEL
#define SET_PIXEL


#include "image.h"


void set_pixel(image m, int x, int y, int c, float val);


#endif