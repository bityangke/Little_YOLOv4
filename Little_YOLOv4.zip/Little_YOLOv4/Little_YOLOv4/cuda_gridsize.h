
#ifndef CUDA_GRIDSIZE
#define CUDA_GRIDSIZE


#include <cuda_runtime.h>


dim3 cuda_gridsize(size_t n);


#endif