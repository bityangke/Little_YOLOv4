
#include "image.h"
#include <opencv2\opencv.hpp>


image mat_to_image(cv::Mat mat);