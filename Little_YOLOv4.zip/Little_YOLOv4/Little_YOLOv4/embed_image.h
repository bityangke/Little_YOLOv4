
#ifndef EMBED_IMAGE
#define EMBED_IMAGE


#include "image.h"


void embed_image(image source, image dest, int dx, int dy);


#endif