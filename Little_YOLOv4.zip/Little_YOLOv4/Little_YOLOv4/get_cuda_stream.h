
#ifndef GET_CUDA_STREAM
#define GET_CUDA_STREAM


#include <cuda_runtime.h>


cudaStream_t get_cuda_stream();


#endif