
#ifndef DRAW_BOX_WIDTH
#define DRAW_BOX_WIDTH


#include "image.h"


void draw_box_width(
    image a, int x1, int y1, int x2, int y2, int w, float r, float g, float b);


#endif