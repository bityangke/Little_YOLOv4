
#ifndef OPTION_FIND
#define OPTION_FIND


#include "list.h"


char* option_find(list* l, char* key);


#endif