
#ifndef GET_NETWORK_INPUT_SIZE
#define GET_NETWORK_INPUT_SIZE


#include "network.h"


int get_network_input_size(network net);


#endif