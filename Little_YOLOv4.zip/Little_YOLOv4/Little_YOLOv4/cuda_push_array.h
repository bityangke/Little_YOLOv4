
#ifndef CUDA_PUSH_ARRAY
#define CUDA_PUSH_ARRAY


void cuda_push_array(float* x_gpu, float* x, size_t n);


#endif