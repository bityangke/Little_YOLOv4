
#ifndef ENTRY_INDEX
#define ENTRY_INDEX


#include "layer.h"


int entry_index(layer l, int batch, int location, int entry);


#endif