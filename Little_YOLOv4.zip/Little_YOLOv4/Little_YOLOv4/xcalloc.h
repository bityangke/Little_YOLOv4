
#ifndef XCALLOC
#define XCALLOC


void* xcalloc(size_t nmemb, size_t size);


#endif