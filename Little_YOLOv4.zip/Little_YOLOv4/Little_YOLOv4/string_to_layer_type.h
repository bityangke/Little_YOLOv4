
#ifndef STRING_TO_LAYER_TYPE
#define STRING_TO_LAYER_TYPE


#include "LAYER_TYPE.h"


LAYER_TYPE string_to_layer_type(char* type);


#endif