
#ifndef NUM_DETECTIONS
#define NUM_DETECTIONS


#include "network.h"


int num_detections(network* net, float thresh);


#endif