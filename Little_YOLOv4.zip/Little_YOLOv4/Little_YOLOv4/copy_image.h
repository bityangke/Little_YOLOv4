
#ifndef COPY_IMAGE
#define COPY_IMAGE


#include "image.h"


image copy_image(image p);


#endif