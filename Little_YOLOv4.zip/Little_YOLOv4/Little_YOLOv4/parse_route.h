
#ifndef PARSE_ROUTE
#define PARSE_ROUTE


#include "layer.h"
#include "list.h"
#include "size_params.h"


layer parse_route(list* options, size_params params);


#endif