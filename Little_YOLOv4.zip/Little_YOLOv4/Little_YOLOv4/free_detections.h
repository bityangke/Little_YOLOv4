
#ifndef FREE_DETECTIONS
#define FREE_DETECTIONS


#include "detection.h"


void free_detections(detection* dets, int n);


#endif