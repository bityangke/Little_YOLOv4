
#ifndef CUDA_PULL_ARRAY_ASYNC
#define CUDA_PULL_ARRAY_ASYNC


void cuda_pull_array_async(float* x_gpu, float* x, size_t n);


#endif