
#ifndef FREE_PTRS
#define FREE_PTRS


void free_ptrs(void** ptrs, int n);


#endif