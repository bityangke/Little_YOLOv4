
#ifndef FORWARD_YOLO_LAYER_GPU
#define FORWARD_YOLO_LAYER_GPU


#include "layer.h"
#include "network_state.h"


void forward_yolo_layer_gpu(const layer l, network_state state);


#endif