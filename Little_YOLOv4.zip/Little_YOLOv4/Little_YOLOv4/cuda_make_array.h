
#ifndef CUDA_MAKE_ARRAY
#define CUDA_MAKE_ARRAY


float* cuda_make_array(float* x, size_t n);


#endif