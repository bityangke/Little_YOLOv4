
#ifndef OPTION_FIND_FLOAT
#define OPTION_FIND_FLOAT


#include "list.h"


float option_find_float(list* l, char* key, float def);


#endif