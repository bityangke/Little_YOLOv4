
#ifndef BOX_IOU
#define BOX_IOU


#include "box.h"


float box_iou(box a, box b);


#endif