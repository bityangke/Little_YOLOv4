
#include "run_detector.h"


int main(int argc, char** argv)
{
    run_detector(argc, argv);
    return 0;
}