
#ifndef STRIP
#define STRIP


void strip(char* s);


#endif