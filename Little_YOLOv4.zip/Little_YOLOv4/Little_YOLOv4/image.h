
#ifndef IMAGE
#define IMAGE


typedef struct image {
    int w;
    int h;
    int c;
    float* data;
} image;


#endif