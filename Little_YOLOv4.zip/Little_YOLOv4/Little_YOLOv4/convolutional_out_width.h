
#ifndef CONVOLUTIONAL_OUT_WIDTH
#define CONVOLUTIONAL_OUT_WIDTH


#include "layer.h"


int convolutional_out_width(layer l);


#endif