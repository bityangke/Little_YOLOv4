
#ifndef FREE_LAYER
#define FREE_LAYER


#include "layer.h"


void free_layer(layer l);


#endif