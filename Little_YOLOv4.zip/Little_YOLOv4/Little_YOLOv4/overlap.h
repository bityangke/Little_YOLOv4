
#ifndef OVERLAP
#define OVERLAP


float overlap(float x1, float w1, float x2, float w2);


#endif