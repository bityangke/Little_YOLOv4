
#ifndef FIND_CHAR_ARG
#define FIND_CHAR_ARG


char* find_char_arg(int argc, char** argv, char* arg, char* def);


#endif