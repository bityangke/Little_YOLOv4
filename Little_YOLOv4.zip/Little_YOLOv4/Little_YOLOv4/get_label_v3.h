
#ifndef GET_LABEL_V3
#define GET_LABEL_V3


#include "image.h"


image get_label_v3(image** characters, char* string, int size);


#endif