
#ifndef GET_ACTIVATION
#define GET_ACTIVATION


#include "ACTIVATION.h"


ACTIVATION get_activation(char* s);


#endif