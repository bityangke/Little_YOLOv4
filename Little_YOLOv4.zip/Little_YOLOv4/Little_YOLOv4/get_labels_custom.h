
#ifndef GET_LABELS_CUSTOM
#define GET_LABELS_CUSTOM


char** get_labels_custom(char* filename, int* size);


#endif