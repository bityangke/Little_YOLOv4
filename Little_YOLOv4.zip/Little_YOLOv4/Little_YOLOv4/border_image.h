
#ifndef BORDER_IMAGE
#define BORDER_IMAGE


#include "image.h"


image border_image(image a, int border);


#endif