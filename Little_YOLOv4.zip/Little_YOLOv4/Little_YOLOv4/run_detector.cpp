
#include "find_float_arg.h"
#include "find_arg.h"
#include "find_char_arg.h"
#include "test_detector.h"


void run_detector(int argc, char** argv)
{
    char* datacfg = argv[3];
    char* cfg = argv[4];
    char* weights = argv[5];
    char* filename = argv[6];

    float thresh = find_float_arg(argc, argv, "-thresh", 0.25);
    float hier_thresh = find_float_arg(argc, argv, "-hier", 0.5);
    int dont_show = find_arg(argc, argv, "-dont_show");
    int benchmark = find_arg(argc, argv, "-benchmark");   
    int ext_output = find_arg(argc, argv, "-ext_output");
    int save_labels = find_arg(argc, argv, "-save_labels");
    char* outfile = find_char_arg(argc, argv, "-out", 0);
    int letter_box = find_arg(argc, argv, "-letter_box");
    int benchmark_layers = find_arg(argc, argv, "-benchmark_layers");

    test_detector(
        datacfg,
        cfg,
        weights,
        filename,
        thresh,
        hier_thresh,
        dont_show,
        ext_output,
        save_labels,
        outfile,
        letter_box,
        benchmark_layers);
}