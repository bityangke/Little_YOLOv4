
#ifndef FUSE_CONV_BATCHNORM
#define FUSE_CONV_BATCHNORM


#include "network.h"


void fuse_conv_batchnorm(network net);


#endif