
#ifndef LOAD_ALPHABET
#define LOAD_ALPHABET


#include "image.h"


image** load_alphabet();


#endif