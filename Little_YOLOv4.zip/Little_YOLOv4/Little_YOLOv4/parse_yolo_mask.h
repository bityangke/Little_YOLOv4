
#ifndef PARSE_YOLO_MASK
#define PARSE_YOLO_MASK


int* parse_yolo_mask(char* a, int* num);


#endif