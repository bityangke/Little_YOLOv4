
#ifndef CHECK_ERROR
#define CHECK_ERROR


#include <cuda_runtime.h>


void check_error(cudaError_t status);


#endif