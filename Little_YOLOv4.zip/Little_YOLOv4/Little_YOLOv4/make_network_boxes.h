
#ifndef MAKE_NETWORK_BOXES
#define MAKE_NETWORK_BOXES


#include "detection.h"
#include "network.h"


detection* make_network_boxes(network* net, float thresh, int* num);


#endif