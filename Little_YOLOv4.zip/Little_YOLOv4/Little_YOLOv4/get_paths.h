
#ifndef GET_PATHS
#define GET_PATHS


#include "list.h"


list* get_paths(char* filename);


#endif