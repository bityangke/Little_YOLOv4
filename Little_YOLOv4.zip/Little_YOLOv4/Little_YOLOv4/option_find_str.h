
#ifndef OPTION_FIND_STR
#define OPTION_FIND_STR


#include "list.h"


char* option_find_str(list* l, char* key, char* def);


#endif