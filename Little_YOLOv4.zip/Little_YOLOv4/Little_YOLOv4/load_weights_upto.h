
#ifndef LOAD_WEIGHTS_UPTO
#define LOAD_WEIGHTS_UPTO


#include "network.h"


void load_weights_upto(network* net, char* filename, int cutoff);


#endif