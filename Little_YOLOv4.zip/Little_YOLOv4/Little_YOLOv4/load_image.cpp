
#ifndef LOAD_IMAGE
#define LOAD_IMAGE


#include "image.h"
#include "load_image_cv.h"


image load_image(char* filename, int w, int h, int c)
{
    return load_image_cv(filename, c);
}


#endif