
#ifndef GET_NUMBER_OF_BLOCKS
#define GET_NUMBER_OF_BLOCKS


int get_number_of_blocks(int array_size, int block_size);


#endif