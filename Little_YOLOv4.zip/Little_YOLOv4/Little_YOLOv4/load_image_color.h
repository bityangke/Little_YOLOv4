
#ifndef LOAD_IMAGE_COLOR
#define LOAD_IMAGE_COLOR


#include "image.h"


image load_image_color(char* filename, int w, int h);


#endif