
#ifndef LOAD_WEIGHTS
#define LOAD_WEIGHTS


#include "network.h"


void load_weights(network* net, char* filename);


#endif