
#ifndef PARSE_UPSAMPLE
#define PARSE_UPSAMPLE


#include "layer.h"
#include "list.h"
#include "size_params.h"


layer parse_upsample(list* options, size_params params, network net);


#endif