
#ifndef FREE_LIST_CONTENTS_KVP
#define FREE_LIST_CONTENTS_KVP


#include "list.h"


void free_list_contents_kvp(list* l);


#endif