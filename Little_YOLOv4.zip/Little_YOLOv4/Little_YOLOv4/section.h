
#ifndef SECTION
#define SECTION


#include "list.h"


typedef struct {
    char* type;
    list* options;
} section;


#endif