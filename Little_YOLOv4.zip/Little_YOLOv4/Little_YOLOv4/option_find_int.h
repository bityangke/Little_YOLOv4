
#ifndef OPTION_FIND_INT
#define OPTION_FIND_INT


#include "list.h"


int option_find_int(list* l, char* key, int def);


#endif