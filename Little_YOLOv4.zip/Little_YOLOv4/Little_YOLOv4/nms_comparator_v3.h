
#ifndef NMS_COMPARATOR_V3
#define NMS_COMPARATOR_V3


int nms_comparator_v3(const void* pa, const void* pb);


#endif