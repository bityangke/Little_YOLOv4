
#ifndef CUDA_GET_DEVICE
#define CUDA_GET_DEVICE


int cuda_get_device();


#endif