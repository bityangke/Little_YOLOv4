
#ifndef LIST_TO_ARRAY
#define LIST_TO_ARRAY


#include "list.h"


void** list_to_array(list* l);


#endif