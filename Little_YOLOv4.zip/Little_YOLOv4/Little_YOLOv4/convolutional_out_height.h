
#ifndef CONVOLUTIONAL_OUT_HEIGHT
#define CONVOLUTIONAL_OUT_HEIGHT


#include "layer.h"


int convolutional_out_height(layer l);


#endif