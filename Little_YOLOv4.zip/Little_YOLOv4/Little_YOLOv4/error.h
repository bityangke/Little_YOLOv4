
#ifndef ERROR
#define ERROR


void error(const char* s);


#endif