
#ifndef GET_COLOR
#define GET_COLOR


float get_color(int c, int x, int max);


#endif