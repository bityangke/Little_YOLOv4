
#ifndef NMS_KIND_H
#define NMS_KIND_H


typedef enum {
    GREEDY_NMS
} NMS_KIND;


#endif