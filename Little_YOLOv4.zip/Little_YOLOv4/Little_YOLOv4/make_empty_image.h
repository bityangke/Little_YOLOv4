
#ifndef MAKE_EMPTY_IMAGE
#define MAKE_EMPTY_IMAGE


#include "image.h"


image make_empty_image(int w, int h, int c);


#endif