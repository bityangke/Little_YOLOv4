
#ifndef WAIT_KEY_CV
#define WAIT_KEY_CV


int wait_key_cv(int delay);


#endif