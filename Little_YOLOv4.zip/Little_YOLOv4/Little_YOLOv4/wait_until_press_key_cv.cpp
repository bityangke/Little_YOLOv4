
#include "wait_key_cv.h"


int wait_until_press_key_cv()
{
    return wait_key_cv(0);
}