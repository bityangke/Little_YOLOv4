
#ifndef YOLO_NUM_DETECTIONS
#define YOLO_NUM_DETECTIONS


#include "layer.h"


int yolo_num_detections(layer l, float thresh);


#endif