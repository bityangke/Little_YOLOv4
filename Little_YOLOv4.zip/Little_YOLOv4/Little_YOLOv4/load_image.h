
#ifndef LOAD_IMAGE
#define LOAD_IMAGE


#include "image.h"


image load_image(char* filename, int w, int h, int c);


#endif