
#ifndef GET_PIXEL
#define GET_PIXEL


#include "image.h"


float get_pixel(image m, int x, int y, int c);


#endif