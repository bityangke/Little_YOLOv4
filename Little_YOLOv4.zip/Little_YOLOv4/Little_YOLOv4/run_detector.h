
#ifndef RUN_DETECTOR
#define RUN_DETECTOR


void run_detector(int argc, char** argv);


#endif