
#ifndef LOAD_CONVOLUTIONAL_WEIGHTS
#define LOAD_CONVOLUTIONAL_WEIGHTS


#include "layer.h"
#include <stdio.h>


void load_convolutional_weights(layer l, FILE* fp);


#endif