
#ifndef STREAM_INIT
#define STREAM_INIT


static int streamInit[16] = { 0 };


#endif