
#ifndef TEST_DETECTOR
#define TEST_DETECTOR


void test_detector(
    char* datacfg,
    char* cfg,
    char* weights,
    char* filename,
    float thresh,
    float hier_thresh,
    int dont_show,
    int ext_output,
    int save_labels,
    char* outfile,
    int letter_box,
    int benchmark_layers);


#endif