
#ifndef FREE_SECTION
#define FREE_SECTION


#include "section.h"


void free_section(section* s);


#endif