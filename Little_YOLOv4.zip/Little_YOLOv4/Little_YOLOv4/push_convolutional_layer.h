
#ifndef PUSH_CONVOLUTIONAL_LAYER
#define PUSH_CONVOLUTIONAL_LAYER


#include "layer.h"


void push_convolutional_layer(layer l);


#endif