
#ifndef CREATE_CONVOLUTIONAL_CUDNN_TENSORS
#define CREATE_CONVOLUTIONAL_CUDNN_TENSORS


#include "layer.h"


void create_convolutional_cudnn_tensors(layer* l);


#endif