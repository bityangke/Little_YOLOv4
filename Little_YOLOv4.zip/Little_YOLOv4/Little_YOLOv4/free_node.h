
#ifndef FREE_NODE
#define FREE_NODE


#include "node.h"


void free_node(node* n);


#endif