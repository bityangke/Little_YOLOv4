
#ifndef LOAD_IMAGE_MAT_CV
#define LOAD_IMAGE_MAT_CV


void* load_image_mat_cv(const char* filename, int flag);


#endif