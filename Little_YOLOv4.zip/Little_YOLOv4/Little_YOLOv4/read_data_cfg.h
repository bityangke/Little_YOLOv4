
#ifndef READ_DATA_CFG
#define READ_DATA_CFG


list* read_data_cfg(char* filename);


#endif