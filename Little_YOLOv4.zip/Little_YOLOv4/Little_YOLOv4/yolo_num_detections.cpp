
#include "layer.h"
#include "entry_index.h"


int yolo_num_detections(layer l, float thresh)
{
    int i, n;
    int count = 0;
    for (n = 0; n < l.n; ++n) {
        for (i = 0; i < l.w * l.h; ++i) {
            int obj_index = entry_index(l, 0, n * l.w * l.h + i, 4);
            if (l.output[obj_index] > thresh) {
                ++count;
            }
        }
    }
    return count;
}