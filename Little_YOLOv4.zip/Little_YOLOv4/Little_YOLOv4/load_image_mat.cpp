
#include <opencv2\opencv.hpp>
#include "load_image_mat_cv.h"


cv::Mat load_image_mat(char* filename, int channels)
{
    cv::Mat* mat_ptr = (cv::Mat*)load_image_mat_cv(filename, cv::IMREAD_COLOR);
    cv::Mat mat = *mat_ptr;
    delete mat_ptr;
    return mat;
}