
#ifndef TILE_IMAGES
#define TILE_IMAGES


#include "image.h"


image tile_images(image a, image b, int dx);


#endif