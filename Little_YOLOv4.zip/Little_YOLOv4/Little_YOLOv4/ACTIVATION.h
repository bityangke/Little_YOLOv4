
#ifndef ACTIVATION_H
#define ACTIVATION_H


typedef enum {
    MISH,
    LINEAR,
    LEAKY,
    LOGISTIC
} ACTIVATION;


#endif