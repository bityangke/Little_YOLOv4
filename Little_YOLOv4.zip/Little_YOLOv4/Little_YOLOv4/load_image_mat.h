
#ifndef LOAD_IMAGE_MAT
#define LOAD_IMAGE_MAT


#include <opencv2\opencv.hpp>


cv::Mat load_image_mat(char* filename, int channels);


#endif