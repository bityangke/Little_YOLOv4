
#include "image.h"
#include <opencv2\opencv.hpp>
#include "make_image.h"


image mat_to_image(cv::Mat mat)
{
    int w = mat.cols;
    int h = mat.rows;
    int c = mat.channels();
    image im = make_image(w, h, c);
    unsigned char* data = (unsigned char*)mat.data;
    int step = mat.step;
    for (int y = 0; y < h; ++y) {
        for (int k = 0; k < c; ++k) {
            for (int x = 0; x < w; ++x) {
                im.data[k * w * h + y * w + x] = data[y * step + x * c + k] / 255.0f;
            }
        }
    }
    return im;
}