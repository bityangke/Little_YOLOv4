
#ifndef COMPOSITE_IMAGE
#define COMPOSITE_IMAGE


#include "image.h"


void composite_image(image source, image dest, int dx, int dy);


#endif