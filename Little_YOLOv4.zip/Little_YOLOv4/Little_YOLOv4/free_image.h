
#ifndef FREE_IMAGE
#define FREE_IMAGE


#include "image.h"


void free_image(image m);


#endif