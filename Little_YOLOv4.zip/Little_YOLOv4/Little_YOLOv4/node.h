
#ifndef NODE
#define NODE


typedef struct node {
    void* val;
    struct node* next;
    struct node* prev;
} node;


#endif