
#ifndef READ_CFG
#define READ_CFG


#include "list.h"


list* read_cfg(char* filename);


#endif