
#ifndef FGETL
#define FGETL


char* fgetl(FILE* fp);


#endif FGETL