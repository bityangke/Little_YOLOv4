
#include "image.h"
#include <opencv2\opencv.hpp>
#include "load_image_mat.h"
#include "mat_to_image.h"


image load_image_cv(char* filename, int channels)
{
    cv::Mat mat = load_image_mat(filename, channels);
    return mat_to_image(mat);
}