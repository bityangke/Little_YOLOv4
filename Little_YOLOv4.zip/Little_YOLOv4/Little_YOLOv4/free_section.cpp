
#include "section.h"
#include <stdlib.h>
#include "kvp.h"


void free_section(section* s)
{
    free(s->type);
    node* n = s->options->front;
    while (n) {
        kvp* pair = (kvp*)n->val;
        free(pair->key);
        free(pair);
        node* next = n->next;
        free(n);
        n = next;
    }
    free(s->options);
    free(s);
}