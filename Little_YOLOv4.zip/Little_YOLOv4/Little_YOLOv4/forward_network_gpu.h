
#ifndef FORWARD_NETWORK_GPU
#define FORWARD_NETWORK_GPU


#include "network.h"
#include "network_state.h"


void forward_network_gpu(network net, network_state state);


#endif