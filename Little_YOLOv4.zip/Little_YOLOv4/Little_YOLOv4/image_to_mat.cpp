
#include <opencv2\opencv.hpp>
#include "image.h"


cv::Mat image_to_mat(image img)
{
    int channels = img.c;
    int width = img.w;
    int height = img.h;
    cv::Mat mat = cv::Mat(height, width, CV_8UC(channels));
    int step = mat.step;

    for (int y = 0; y < img.h; ++y) {
        for (int x = 0; x < img.w; ++x) {
            for (int c = 0; c < img.c; ++c) {
                float val = img.data[c * img.h * img.w + y * img.w + x];
                mat.data[y * step + x * img.c + c] = (unsigned char)(val * 255);
            }
        }
    }
    return mat;
}