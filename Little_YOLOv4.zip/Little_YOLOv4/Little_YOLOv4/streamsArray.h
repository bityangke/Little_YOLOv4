
#ifndef STREAMS_ARRAY
#define STREAMS_ARRAY


#include <cuda_runtime.h>


static cudaStream_t streamsArray[16];


#endif