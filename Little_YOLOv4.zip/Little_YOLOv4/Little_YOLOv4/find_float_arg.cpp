
#include <string.h>
#include <stdlib.h>


float find_float_arg(int argc, char** argv, char* arg, float def)
{
    for (int i = 0; i < argc - 1; ++i) {
        if (strcmp(argv[i], arg) == 0) {
            return atof(argv[i + 1]);
        }
    }
    return def;
}