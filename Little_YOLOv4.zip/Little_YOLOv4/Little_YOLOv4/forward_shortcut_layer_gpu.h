
#ifndef FORWARD_SHORTCUT_LAYER_GPU
#define FORWARD_SHORTCUT_LAYER_GPU


#include "layer.h"
#include "network_state.h"


void forward_shortcut_layer_gpu(const layer l, network_state state);


#endif