
#ifndef CUDA_SET_DEVICE
#define CUDA_SET_DEVICE


void cuda_set_device(int n);


#endif