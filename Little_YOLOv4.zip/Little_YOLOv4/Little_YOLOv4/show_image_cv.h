
#ifndef SHOW_IMAGE_CV
#define SHOW_IMAGE_CV


#include "image.h"


void show_image_cv(image p, const char* name);


#endif