
#ifndef PARSE_SHORTCUT
#define PARSE_SHORTCUT


#include "layer.h"
#include "list.h"
#include "size_params.h"


layer parse_shortcut(list* options, size_params params, network net);


#endif