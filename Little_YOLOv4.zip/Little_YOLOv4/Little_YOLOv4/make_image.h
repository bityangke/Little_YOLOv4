
#ifndef MAKE_IMAGE
#define MAKE_IMAGE


#include "image.h"


image make_image(int w, int h, int c);


#endif