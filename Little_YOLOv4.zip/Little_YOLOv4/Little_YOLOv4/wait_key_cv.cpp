
#include <opencv2\opencv.hpp>


int wait_key_cv(int delay)
{
    return cv::waitKey(delay);
}