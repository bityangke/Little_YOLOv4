
#ifndef SHOW_IMAGE
#define SHOW_IMAGE


#include "image.h"


void show_image(image p, const char* name);


#endif