
#include "list.h"
#include <stdio.h>
#include "make_list.h"
#include "fgetl.h"
#include "strip.h"
#include <stdlib.h>
#include "read_option.h"


list* read_data_cfg(char* filename)
{
    FILE* file = fopen(filename, "r");
    char* line;
    list* options = make_list();
    while ((line = fgetl(file)) != 0) {
        strip(line);
        switch (line[0]) {
        case '\0':
            free(line);
            break;
        case '#':
            free(line);
            break;
        default:
            read_option(line, options);
            break;
        }
    }
    fclose(file);
    return options;
}