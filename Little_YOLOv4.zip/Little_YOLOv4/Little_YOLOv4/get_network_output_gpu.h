
#ifndef GET_NETWORK_OUTPUT_GPU
#define GET_NETWORK_OUTPUT_GPU


#include "network.h"


float* get_network_output_gpu(network net);


#endif