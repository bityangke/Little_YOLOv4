
#ifndef PARSE_YOLO
#define PARSE_YOLO


#include "layer.h"
#include "list.h"
#include "size_params.h"


layer parse_yolo(list* options, size_params params);


#endif