
#ifndef CUDA_FREE
#define CUDA_FREE


void cuda_free(float* x_gpu);


#endif