
#ifndef GET_WORKSPACE_SIZE32
#define GET_WORKSPACE_SIZE32


#include "layer.h"


size_t get_workspace_size32(layer l);


#endif