
#ifndef FIND_ARG
#define FIND_ARG


int find_arg(int argc, char* argv[], char* arg);


#endif