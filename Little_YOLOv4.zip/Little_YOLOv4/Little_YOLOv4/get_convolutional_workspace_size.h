
#ifndef GET_CONVOLUTIONAL_WORKSPACE_SIZE
#define GET_CONVOLUTIONAL_WORKSPACE_SIZE


#include "layer.h"


size_t get_convolutional_workspace_size(layer l);


#endif