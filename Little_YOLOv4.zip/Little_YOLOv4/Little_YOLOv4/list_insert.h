
#ifndef LIST_INSERT
#define LIST_INSERT


void list_insert(list* l, void* val);


#endif