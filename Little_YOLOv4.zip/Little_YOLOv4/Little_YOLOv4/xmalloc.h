
#ifndef XMALLOC
#define XMALLOC


void* xmalloc(size_t size);


#endif