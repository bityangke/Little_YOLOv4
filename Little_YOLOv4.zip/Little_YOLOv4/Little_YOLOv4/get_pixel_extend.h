
#ifndef GET_PIXEL_EXTEND
#define GET_PIXEL_EXTEND


#include "image.h"


float get_pixel_extend(image m, int x, int y, int c);


#endif
