
#ifndef NETWORK_PREDICT
#define NETWORK_PREDICT


#include "network.h"


float* network_predict(network net, float* input);


#endif